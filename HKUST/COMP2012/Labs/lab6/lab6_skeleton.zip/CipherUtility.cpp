#include "CipherUtility.h"

// TODO #5
// Implement the static member function isKeyValid
 

// TODO #6
// Implement the static member function removeNonAlphaCharsHelper
