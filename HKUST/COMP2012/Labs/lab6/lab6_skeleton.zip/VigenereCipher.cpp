#include "VigenereCipher.h"
#include "Utility.h"

// TODO #1
// Initialize the static data member alphabetSize here


// TODO #2
// Implement the encrypt member function according to the given algoirthm.


// TODO #3
// Implement the decrypt member function according to the given algoirthm.


// TODO #4
// Implement the static member function generateRandomKey
// according to the given algorithm.
