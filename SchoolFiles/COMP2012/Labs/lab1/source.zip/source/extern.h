#ifndef EXTERN_H
#define EXTERN_H

/*  File: extern.h  */
extern const int LOW;
extern const int MODERATE;
extern const int HIGH;

#endif