#ifndef GLOBAL_H
#define GLOBAL_H

/*  File: global.h  */
int LOW = 0;
int MODERATE = 1;
int HIGH = 2;

#endif