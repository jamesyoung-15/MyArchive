#ifndef BOAR_H
#define BOAR_H

#include "Animal.h"

//  TODO: Complete the class declaration of Boar



#endif