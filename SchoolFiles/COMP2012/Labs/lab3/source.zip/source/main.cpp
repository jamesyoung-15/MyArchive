#include "Boar.h"
#include "StrayDog.h"
#include "TherapyDog.h"

int main() {
    TherapyDog tdog{"Coffee", "UST", "full-time"};
    Boar boar{"Bob", "UST"};
    StrayDog sdog1{"Doge", "UST", "yellow"};
    StrayDog sdog2{"Dollar", "UST", "brown"};

//  TODO: Complete the main function

    return 0;
}
